#include <config.h>
#include <gtk/gtk.h>

#include <glib/gi18n.h>
#include "window_defs_n_config.h"

void create_keypad_objects(){
	
}